<?php include 'header.php';?>
<section class="inner-bnr relative" data-overlay="6" style="background-image:url(https://dishafoundation.org/images/pg-cover.jpg)">
        <div class="inner-banner-in transform-center z-5">
            <h1 class="slab yellow fs-54">Make a Donation
                <img src="https://dishafoundation.org/images/title-bg.png" class="transform-center" alt="Image"/>
            </h1>
            <ul class="inner-bnr-nav mt-75">
                <li><a href="https://dishafoundation.org/">Home </a></li>
                <li>THANK YOU</li>
            </ul>
        </div>
</section>  
<section class="wo-are bg-light-white pt-50 pb-90">
        <div class="container">
            <div class="row">
                <div class="col-lg-10 offset-lg-1 text-center">
                    
                    <h2 class="fs-42 slab f-800">Your payment was successfully made. </h2>
                    
                </div>
            </div>
         </div>
    </section>

                  
<?php include 'footer.php';?>
    

