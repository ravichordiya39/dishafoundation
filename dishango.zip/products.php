<?php include 'header.php';?>
<section class="inner-bnr relative" data-overlay="6" style="background-image:url(https://dishafoundation.org/images/pg-cover.jpg)">
        <div class="inner-banner-in transform-center z-5">
            <h1 class="slab yellow fs-54">Products
                <img src="https://dishafoundation.org/images/title-bg.png" class="transform-center" alt="Image"/>
            </h1>
            <ul class="inner-bnr-nav mt-75">
                <li><a href="https://dishafoundation.org/">Home </a></li>
                <li>Products</li>
            </ul>
        </div>
</section> 
<section class="shop-list bg-light-white pt-90 pb-90">
        <div class="container">
            
            <div class="row">
                <div class="col-lg-9">
                    <div class="row">
                        <div class="col-xl-4 col-lg-6 col-md-6">
                            <div class="each-shop-list">
                                <div class="shop-imag">
                                    <img src="https://dishafoundation.org/images/products/gift-pack.jpg" alt="Image">
                                   
                                </div>
                                <div class="shop-text">
                                    <h4 class="slab"><a href="https://dishafoundation.org/products-singal/">Buddha Bracelet</a></h4>
                                    
                                    <div class="d-flex shp-buttons justify-content-center">
                                        <div>
                                            <a href="https://dishafoundation.org/products-singal/" class="btn add-cart">View </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6">
                            <div class="each-shop-list">
                                <div class="shop-imag">
                                    <img src="https://dishafoundation.org/images/products/gift-pack.jpg" alt="Image">
                                   
                                </div>
                                <div class="shop-text">
                                    <h4 class="slab"><a href="https://dishafoundation.org/products-singal/">Buddha Bracelet</a></h4>
                                    
                                    <div class="d-flex shp-buttons justify-content-center">
                                        <div>
                                            <a href="https://dishafoundation.org/products-singal/" class="btn add-cart">View </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6">
                            <div class="each-shop-list">
                                <div class="shop-imag">
                                    <img src="https://dishafoundation.org/images/products/gift-pack.jpg" alt="Image">
                                   
                                </div>
                                <div class="shop-text">
                                    <h4 class="slab"><a href="https://dishafoundation.org/products-singal/">Buddha Bracelet</a></h4>
                                    
                                    <div class="d-flex shp-buttons justify-content-center">
                                        <div>
                                            <a href="https://dishafoundation.org/products-singal/" class="btn add-cart">View </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6">
                            <div class="each-shop-list">
                                <div class="shop-imag">
                                    <img src="https://dishafoundation.org/images/products/gift-pack.jpg" alt="Image">
                                   
                                </div>
                                <div class="shop-text">
                                    <h4 class="slab"><a href="https://dishafoundation.org/products-singal/">Buddha Bracelet</a></h4>
                                    
                                    <div class="d-flex shp-buttons justify-content-center">
                                        <div>
                                            <a href="https://dishafoundation.org/products-singal/" class="btn add-cart">View </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6">
                            <div class="each-shop-list">
                                <div class="shop-imag">
                                    <img src="https://dishafoundation.org/images/products/gift-pack.jpg" alt="Image">
                                   
                                </div>
                                <div class="shop-text">
                                    <h4 class="slab"><a href="https://dishafoundation.org/products-singal/">Buddha Bracelet</a></h4>
                                    
                                    <div class="d-flex shp-buttons justify-content-center">
                                        <div>
                                            <a href="https://dishafoundation.org/products-singal/" class="btn add-cart">View </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6">
                            <div class="each-shop-list">
                                <div class="shop-imag">
                                    <img src="https://dishafoundation.org/images/products/gift-pack.jpg" alt="Image">
                                   
                                </div>
                                <div class="shop-text">
                                    <h4 class="slab"><a href="https://dishafoundation.org/products-singal/">Buddha Bracelet</a></h4>
                                    
                                    <div class="d-flex shp-buttons justify-content-center">
                                        <div>
                                            <a href="https://dishafoundation.org/products-singal/" class="btn add-cart">View </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6">
                            <div class="each-shop-list">
                                <div class="shop-imag">
                                    <img src="https://dishafoundation.org/images/products/gift-pack.jpg" alt="Image">
                                   
                                </div>
                                <div class="shop-text">
                                    <h4 class="slab"><a href="https://dishafoundation.org/products-singal/">Buddha Bracelet</a></h4>
                                    
                                    <div class="d-flex shp-buttons justify-content-center">
                                        <div>
                                            <a href="https://dishafoundation.org/products-singal/" class="btn add-cart">View </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6">
                            <div class="each-shop-list">
                                <div class="shop-imag">
                                    <img src="https://dishafoundation.org/images/products/gift-pack.jpg" alt="Image">
                                   
                                </div>
                                <div class="shop-text">
                                    <h4 class="slab"><a href="https://dishafoundation.org/products-singal/">Buddha Bracelet</a></h4>
                                    
                                    <div class="d-flex shp-buttons justify-content-center">
                                        <div>
                                            <a href="https://dishafoundation.org/products-singal/" class="btn add-cart">View </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6">
                            <div class="each-shop-list">
                                <div class="shop-imag">
                                    <img src="https://dishafoundation.org/images/products/gift-pack.jpg" alt="Image">
                                   
                                </div>
                                <div class="shop-text">
                                    <h4 class="slab"><a href="https://dishafoundation.org/products-singal/">Buddha Bracelet</a></h4>
                                    
                                    <div class="d-flex shp-buttons justify-content-center">
                                        <div>
                                            <a href="https://dishafoundation.org/products-singal/" class="btn add-cart">View </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                     <div class="sidebar-outer h-100">
                        <div class="side-box">
                            <form action="#" class="relative mt-10 mb-10">
                                <input type="text" class="form-control input-white search-white shadow-5" id="search2" placeholder="Search here.."> <i class="fas fa-search transform-v-center transition-4 yellow"></i>
                            </form>
                        </div>
                        <div class="side-box ">
                            <h4 class="f-700 slab mb-20 mt-5">Popular Products</h4>
                            <div class="popular-posts mb-10">
                                <a href="https://dishafoundation.org/products-singal/" class="popular-post d-flex align-items-center">
                                    <div class="popular-post-img mr-20">
                                        <img src="https://dishafoundation.org/images/products/gift-pack.jpg" alt="Image">
                                        <div class="full-cover bg-yellow-op-8 transition-4"> <i class="fas fa-external-link-alt transform-center"></i>
                                        </div>
                                    </div>
                                    <div class="popular-post-text">
                                        <p class="mb-5 fs-16 f-700 slab">Black Lace Choker</p> <span class="fs-12 f-700 yellow">$33.00</span>
                                    </div>
                                </a>
                                <a href="https://dishafoundation.org/products-singal/" class="popular-post d-flex align-items-center">
                                    <div class="popular-post-img mr-20">
                                        <img src="https://dishafoundation.org/images/products/gift-pack.jpg" alt="Image">
                                        <div class="full-cover bg-yellow-op-8 transition-4"> <i class="fas fa-external-link-alt transform-center"></i>
                                        </div>
                                    </div>
                                    <div class="popular-post-text">
                                        <p class="mb-5 fs-16 f-700 slab">Black Lace Choker</p> <span class="fs-12 f-700 yellow">$33.00</span>
                                    </div>
                                </a>
                                <a href="https://dishafoundation.org/products-singal/" class="popular-post d-flex align-items-center">
                                    <div class="popular-post-img mr-20">
                                        <img src="https://dishafoundation.org/images/products/gift-pack.jpg" alt="Image">
                                        <div class="full-cover bg-yellow-op-8 transition-4"> <i class="fas fa-external-link-alt transform-center"></i>
                                        </div>
                                    </div>
                                    <div class="popular-post-text">
                                        <p class="mb-5 fs-16 f-700 slab">Black Lace Choker</p> <span class="fs-12 f-700 yellow">$33.00</span>
                                    </div>
                                </a>
                            </div>
                        </div>
                        
                    </div>
                </div>
              
            </div>
        </div>
    </section>
<?php include 'footer.php';?>